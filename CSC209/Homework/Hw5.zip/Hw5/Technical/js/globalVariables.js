const RADIUS = 20;
const LINE_LENGTH = 7;
const LINE_WIDTH = 5;

let circles = [];

const COLORS = [
  "red",
  "orange",
  "yellow",
  "green",
  "blue",
  "purple",
  "pink",
  "black",
  "gray",
  "brown",
  "cyan",
  "magenta",
  "lime",
  "teal",
  "navy",
  "maroon",
  "olive",
  "gold",
  "silver",
  "indigo",
  "violet",
  "coral",
  "turquoise",
  "beige",
  "lavender",
  "salmon",
  "chocolate",
  "crimson",
  "aqua"
]