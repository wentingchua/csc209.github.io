<html>

<head>
    <?php
    if (!isset($_SESSION['username'])) {
        header("Location: ../login.html.php");
        exit;
    }
    $username = $_SESSION['username'];
    // $loggedtimes = $_POST['loggedtimes'];
    include("../php/extractFolderNumber.php")
        ?>
    <script src="../js/handleUserAction.js"></script>
    <script>
        let loginStartTime
        let loginDuration = 0
        let folderNumber = <?php echo extractFolderNumber(realpath("./")) ?>
    </script>
</head>

<body>
    <script>startTimer()</script>
    <h1>Welcome</h1>
    <h2>
        <?php
        echo "User: " . $username . "<br>";
        echo "Logged times: " . $loggedtimes . "<br>";
        // echo extractFolderNumber(realpath("./"))
        ?>
    </h2>
    <form id="logoutForm" action="../../logout.html.php" method="POST">
        <input type="hidden" id="minutesLoggedIn" name="minutesLoggedIn">
        <input type="hidden" id="folderNumber" name="folderNumber">
    </form>
    <button onclick="handleLogout()">Logout</button>
</body>

</html>