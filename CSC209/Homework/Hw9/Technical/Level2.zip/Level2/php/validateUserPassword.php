<?php
session_start();
$username = $_POST["username"] ?? '';
$password = $_POST["password"] ?? '';

function validateUserAndPassword($username, $password)
{
    $json_path = "../users.json";
    $json_data = file_get_contents($json_path);
    $obj = json_decode($json_data);

    foreach ($obj as $index => $user) {
        if ($user->username === $username && $user->password === $password) {
            $user->loggedtimes++;
            $obj[$index] = $user;
            $updated_json_data = json_encode($obj);
            file_put_contents($json_path, $updated_json_data);
            return ['user' => $user, 'index' => $index];
        }
    }
    return null;
}

// session_unset();
// session_destroy();

$item = validateUserAndPassword($username, $password);

if ($item) {
    $user = $item['user'];
    $index = $item['index'];
    // if ($user->isAdmin) {
    //     $target = "Admin/admin.html.php";
    // } else {
    //     $target = "User/User" . ($index + 1) . "/user.html.php";
    // }
    // echo '
    //     <!DOCTYPE html>
    //     <html>
    //     <body>
    //     <form id="redirectForm" action=' . $target . ' method="POST">
    //         <input type="hidden" name="username" value="' . $username . '">
    //         <input type="hidden" name="loggedtimes" value="' . $user->loggedtimes . '">
    //     </form>
    //     <script>
    //         document.getElementById("redirectForm").submit();
    //     </script>
    //     </body>
    //     </html>
    // ';
    $_SESSION['username'] = $item->username;
    if ($item['index'] == 0) {
        $target_path = "Location: ../html/admin.html.php";
    } else {
        $target_path = "Location: ../html/user.html.php";
    }
    header($target_path);
    exit;
} else {
    echo "<script>
            alert('Invalid username or password.');
            window.history.back();
          </script>";
    exit;
}
?>