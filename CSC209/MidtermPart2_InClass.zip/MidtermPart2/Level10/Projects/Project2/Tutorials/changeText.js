function changeText() {
    document.getElementById("demo").innerHTML = "The text has been changed!"
}