function addRow(name, isPart1Checked, isPart2Checked) {
    // const checkCross1 = isPart1Checked ? "fa fa-check" : "fa fa-remove";
    // const checkCross2 = isPart2Checked ? "fa fa-check" : "fa fa-remove";
    // const newRow = ROW.replace("TEXT", name).replace("CHECKCROSS1", checkCross1).replace("CHECKCROSS2", checkCross2);
    // const table = document.getElementById("table");
    // table.innerHTML += newRow;
    const row = document.createElement("tr");
    const nameData = document.createElement("td");
    const part1Data = document.createElement("td");
    const part1Value = document.createElement("i");
    const part2Data = document.createElement("td")
    const part2Value = document.createElement("i");
    nameData.innerHTML = name;
    part1Value
}

function addRows() {
    for (let i = 0; i < NRROWS; i++) {
        const isPart1Checked = PART1[i];
        const isPart2Checked = PART2[i];
        const name = NAMES[i];
        addRow(name, isPart1Checked, isPart2Checked);
    }
}
