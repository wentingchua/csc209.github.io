<?php
session_start();

$username = $_POST["username"] ?? '';
$password = $_POST["password"] ?? '';

function validateUserAndPassword($username, $password)
{
    $json_path = "users.json";
    $json_data = file_get_contents($json_path);
    $obj = json_decode($json_data);

    foreach ($obj as $user) {
        if ($user->username === $username && $user->password === $password) {
            $user->loggedtimes ++;
            $updated_json_data = json_encode($obj);
            file_put_contents($json_path, $updated_json_data);
            return $user;
        }
    }
    return null;
}

$user = validateUserAndPassword($username, $password);

if ($user) {
    // store username in session
    $_SESSION["user_info"] = ["username" => $username, "loggedtimes" => $user->loggedtimes];

    header("Location: user.html.php");
    exit;
} else {
    echo "<script>
            alert('Invalid username or password.');
            window.history.back();
          </script>";
    exit;
}
?>
