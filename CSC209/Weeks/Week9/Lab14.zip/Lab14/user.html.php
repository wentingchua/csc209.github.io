<html>
    <head>
        <?php
            session_start();
            $user_info = $_SESSION['user_info']
        ?>
    </head>
    <body>
        <h1>Welcome</h1>
        <h2>
            <?php
            echo "User: " . $user_info["username"] . "<br>";
            echo "Logged times: " . $user_info["loggedtimes"]
            ?>
        </h2>
    </body>
</html>