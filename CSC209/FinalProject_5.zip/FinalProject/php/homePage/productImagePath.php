<?php
$category = $_GET["category"] ?? "";
$product_id = $_GET["product_id"] ?? "";
$path = "../../products/$category/";
$image_paths = scandir($path);
foreach ($image_paths as $path) {
    if (str_contains($path, "")) {
        echo $path;
        exit();
    }
}
echo "File not found."
?>